1. Run `npm install`
   It will install all the dependencies in node_modules.

2. Run `npm start`
   It will start the project at http://localhost:3000/.

3. Open Developer tools and check the Redux dev tool
   